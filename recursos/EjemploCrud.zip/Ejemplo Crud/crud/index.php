<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>INDEX</title>
	<h2>Ejemplo CRUD</h2>
</head>
<body>
	<form action="./procesos/guardarDatos.php" method="POST">
	<br><a href='guardar.php'>Crear<a>
	<br><a href='buscador.php'>Buscar<a>
	<br><a href='seleccionar.php'>Listar<a>
	</form>
</body>
</html>