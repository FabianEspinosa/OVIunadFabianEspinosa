<?php
	require_once "../php/connect.php";
	$id=$_POST['id'];
	$nombre=$_POST['nombre'];
	$apellido=$_POST['apellido'];
	$email=$_POST['email'];
		$campos="nombre='$nombre',apellido='$apellido',email='$email'";	
	$query="UPDATE usuarios SET $campos WHERE id='$id'";
	if($mysqli->query($query)){
		echo "Datos actualizados";
		echo "<br><a href='../index.php'>volver<a>";
	}else{
		echo "Error no se pudo actualizar los datos";
		echo "<br><a href='../index.php'>volver<a>";
	}