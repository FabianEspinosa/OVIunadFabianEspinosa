<?php
	require_once "../php/connect.php";
	$nombre=$_POST['nombre'];
	$apellido=$_POST['apellido'];
	$email=$_POST['email'];
	$query="INSERT INTO usuarios(nombre,apellido,email) VALUES('$nombre','$apellido','$email')";
	if($mysqli->query($query)){
		echo "Datos guardados";
		echo "<br><a href='../index.php'>volver<a>";
	}else{
		echo "Ocurrio un error";
		echo "<br><a href='../index.php'>volver<a>";
	}